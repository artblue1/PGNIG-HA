"""Pgnig HA sensor"""
