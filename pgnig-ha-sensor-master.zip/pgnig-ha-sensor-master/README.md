# PGNIG HA Sensor

Na podstawie:
https://github.com/pawelhulek/pgnig-sensor
